<?php
require_once "controllers/UserController.php";

$userController = new UserController();

// Prueba el registro
$response = $userController->register("testuser", "123456");
echo json_encode($response);
?>
