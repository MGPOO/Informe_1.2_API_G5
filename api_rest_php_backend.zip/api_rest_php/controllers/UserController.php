<?php
require_once __DIR__ . "/../config/database.php";

class UserController {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function register($username, $password) {
        // Verificar si el usuario ya existe
        $query = "SELECT * FROM users WHERE username = :username";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $username);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return ["success" => false, "message" => "El usuario ya existe."];
        }

        // Cifrar la contraseña
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Insertar el usuario en la base de datos
        $query = "INSERT INTO users (username, password) VALUES (:username, :password)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":password", $hashedPassword);

        if ($stmt->execute()) {
            return ["success" => true, "message" => "Usuario registrado exitosamente."];
        } else {
            return ["success" => false, "message" => "Error al registrar el usuario."];
        }
    }

    public function login($username, $password) {
        // Buscar el usuario en la base de datos
        $query = "SELECT * FROM users WHERE username = :username";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $username);
        $stmt->execute();
    
        if ($stmt->rowCount() > 0) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Verificar la contraseña
            if (password_verify($password, $user['password'])) {
                return [
                    "success" => true,
                    "message" => "Inicio de sesión exitoso.",
                    "user" => [
                        "id" => $user['id'],
                        "username" => $user['username'],
                        "created_at" => $user['created_at']
                    ]
                ];
            } else {
                return ["success" => false, "message" => "Contraseña incorrecta."];
            }
        } else {
            return ["success" => false, "message" => "Usuario no encontrado."];
        }
    }
    
    public function getUsers() {
        // Consultar todos los usuarios
        $query = "SELECT id, username, created_at FROM users";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getUserById($id) {
        // Consultar un usuario por su ID
        $query = "SELECT id, username, created_at FROM users WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function updateUser($id, $username, $password) {
        // Actualizar un usuario
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $query = "UPDATE users SET username = :username, password = :password WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":password", $hashedPassword);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }
    
    public function deleteUser($id) {
        // Eliminar un usuario
        $query = "DELETE FROM users WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }
    
    
}
?>
