<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

header("Content-Type: application/json");

if (isset($_GET['route']) && ($_GET['route'] === "register" || $_GET['route'] === "login")) {
    require_once "routes/user.php";
} elseif (isset($_GET['route']) && $_GET['route'] === "crud") {
    require_once "routes/user.php";
} else {
    echo json_encode(["success" => false, "message" => "Ruta no encontrada."]);
}
?>
