<?php
class Database {
    private $host = "localhost";
    private $db_name = "api_flutter";
    private $username = "root"; // Usuario por defecto en XAMPP
    private $password = "";     // Contraseña vacía por defecto en XAMPP
    public $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8"); // Configurar codificación UTF-8
        } catch(PDOException $exception) {
            echo "Error de conexión: " . $exception->getMessage();
        }

        return $this->conn;
    }
}
?>
