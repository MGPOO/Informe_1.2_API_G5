<?php
require_once __DIR__ . "/../controllers/UserController.php";


$userController = new UserController();

// Leer datos del cuerpo de la solicitud
$data = json_decode(file_get_contents("php://input"), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($data['username']) && isset($data['password'])) {
    $response = $userController->register($data['username'], $data['password']);
    echo json_encode($response);
} else {
    echo json_encode(["success" => false, "message" => "Método no permitido o datos incompletos."]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'login') {
    if (isset($data['username']) && isset($data['password'])) {
        $response = $userController->login($data['username'], $data['password']);
        echo json_encode($response);
    } else {
        echo json_encode(["success" => false, "message" => "Datos incompletos para el inicio de sesión."]);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action'])) {
    if ($_GET['action'] === 'getUsers') {
        echo json_encode($userController->getUsers());
    } elseif ($_GET['action'] === 'getUserById' && isset($_GET['id'])) {
        echo json_encode($userController->getUserById($_GET['id']));
    } else {
        echo json_encode(["success" => false, "message" => "Acción no válida."]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'PUT' && isset($_GET['action']) && $_GET['action'] === 'updateUser') {
    $data = json_decode(file_get_contents("php://input"), true);
    if (isset($data['id'], $data['username'], $data['password'])) {
        $success = $userController->updateUser($data['id'], $data['username'], $data['password']);
        echo json_encode(["success" => $success]);
    } else {
        echo json_encode(["success" => false, "message" => "Datos incompletos."]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['action']) && $_GET['action'] === 'deleteUser') {
    if (isset($_GET['id'])) {
        $success = $userController->deleteUser($_GET['id']);
        echo json_encode(["success" => $success]);
    } else {
        echo json_encode(["success" => false, "message" => "ID no proporcionado."]);
    }
}

?>

